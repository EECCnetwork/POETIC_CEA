######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)
library(heemod)

#load the information

set.seed(123)

source("Markov_Model/probabilistic_analysis/probabilistic_nothing_vs_interventions.R")

source("Markov_Model/probabilistic_analysis/probabilistic_tanzania_vs_interventions.R")


source("Markov_Model/probabilistic_analysis/probabilistic_isaric_vs_interventions.R")

#craft table of absolute mortality rates, deaths, costs for no critical care


nothing_mortality_rates <- nothing_dat$DEATHS/pop
nothing_DALY_dat
nothing_totalcost_dat

tim_worry_nothingdat <- data.frame(Mortality_rate = round(nothing_mortality_rates,2), 
                                   DALYs = nothing_DALY_dat,
                                   Costs = nothing_totalcost_dat)

nothing_eecc_mortality_rates <- no_eecc_dat$DEATHS/pop
no_eecc_DALY_dat
no_eecc_totalcost_dat

tim_worry_noeeccdat <- data.frame(Mortality_rate = round(nothing_eecc_mortality_rates,2), 
                                  DALYs = no_eecc_DALY_dat,
                                  Costs = no_eecc_totalcost_dat)

nothing_eeccaos_mortality_rates <- no_eeccaos_dat$DEATHS/pop
no_eeccaos_DALY_dat
no_eeccaos_totalcost_dat


tim_worry_noeeccaosdat <- data.frame(Mortality_rate = round(nothing_eeccaos_mortality_rates,2), 
                                  DALYs = no_eeccaos_DALY_dat,
                                  Costs = no_eeccaos_totalcost_dat)

#find corresponding mortality rate to which tim wants

half_numbers_nothing <- which(tim_worry_nothingdat$Mortality_rate == 0.36)

nothing_timworry_results <- tim_worry_nothingdat[half_numbers_nothing,]
nothingeecc_timworry_results <- tim_worry_noeeccdat[half_numbers_nothing,]
nothingeeccaos_timworry_results <- tim_worry_noeeccaosdat[half_numbers_nothing,]

halfnumbers_mean_nothing <- rbind(nothing_timworry_results[2,],
                               nothingeecc_timworry_results[2,],
                               nothingeeccaos_timworry_results[2,])


tim_worry_noeecc_inc_dalys <- halfnumbers_mean_nothing[1,2] - halfnumbers_mean_nothing[2,2]
tim_worry_noeeccaoc_inc_dalys <- halfnumbers_mean_nothing[1,2] - halfnumbers_mean_nothing[3,2]
tim_worry_noeecc_inc_costs <- halfnumbers_mean_nothing[2,3] - halfnumbers_mean_nothing[1,3]
tim_worry_noeeccaoc_inc_costs <-  halfnumbers_mean_nothing[3,3] - halfnumbers_mean_nothing[1,3]

tim_worry_noeecc_ICER <- tim_worry_noeecc_inc_costs/tim_worry_noeecc_inc_dalys
tim_worry_noeeccaos_ICER <- tim_worry_noeeccaoc_inc_costs/tim_worry_noeeccaoc_inc_dalys

incremental_details_nothing <- data.frame(inc_dalys = c(NA,tim_worry_noeecc_inc_dalys,tim_worry_noeeccaoc_inc_dalys),
                                          inc_costs = c(NA, tim_worry_noeecc_inc_costs, tim_worry_noeeccaoc_inc_costs),
                                          ICER = c(NA, tim_worry_noeecc_ICER, tim_worry_noeeccaos_ICER))

#craft table of absolute mortality rates, deaths, costs for tz critical care


tanzania_mortality_rates <- tanzania_dat$DEATHS/pop
tanzania_DALY_dat
tanzania_totalcost_dat

tim_worry_tanzaniadat <- data.frame(Mortality_rate = round(tanzania_mortality_rates,2), 
                                   DALYs = tanzania_DALY_dat,
                                   Costs = tanzania_totalcost_dat)

tanzania_eecc_mortality_rates <- tz_eecc_dat$DEATHS/pop
tz_eecc_DALY_dat
tz_eecc_totalcost_dat

tim_worry_tzeeccdat <- data.frame(Mortality_rate = round(tanzania_eecc_mortality_rates,2), 
                                  DALYs = tz_eecc_DALY_dat,
                                  Costs = tz_eecc_totalcost_dat)

tanzania_eeccaos_mortality_rates <- tz_eeccaos_dat$DEATHS/pop
tz_eeccaos_DALY_dat
tz_eeccaos_totalcost_dat


tim_worry_tzeeccaosdat <- data.frame(Mortality_rate = round(tanzania_eeccaos_mortality_rates,2), 
                                     DALYs = tz_eeccaos_DALY_dat,
                                     Costs = tz_eeccaos_totalcost_dat)

#find corresponding mortality rate to which tim wants

half_numbers_tz <- which(tim_worry_tanzaniadat$Mortality_rate == 0.32)

tanzania_timworry_results <- tim_worry_tanzaniadat[half_numbers_tz,]
tanzaniaeecc_timworry_results <- tim_worry_tzeeccdat[half_numbers_tz,]
tanzaniaeeccaos_timworry_results <- tim_worry_tzeeccaosdat[half_numbers_tz,]

halfnumbers_mean_tanzania <- rbind(tanzania_timworry_results[4,],
                                  tanzaniaeecc_timworry_results[4,],
                                  tanzaniaeeccaos_timworry_results[4,])


tim_worry_tzeecc_inc_dalys <- halfnumbers_mean_tanzania[1,2] - halfnumbers_mean_tanzania[2,2]
tim_worry_tzeeccaoc_inc_dalys <- halfnumbers_mean_tanzania[1,2] - halfnumbers_mean_tanzania[3,2]
tim_worry_tzeecc_inc_costs <- halfnumbers_mean_tanzania[2,3] - halfnumbers_mean_tanzania[1,3]
tim_worry_tzeeccaoc_inc_costs <-  halfnumbers_mean_tanzania[3,3] - halfnumbers_mean_tanzania[1,3]

tim_worry_tzeecc_ICER <- tim_worry_tzeecc_inc_costs/tim_worry_tzeecc_inc_dalys
tim_worry_tzeeccaos_ICER <- tim_worry_tzeeccaoc_inc_costs/tim_worry_tzeeccaoc_inc_dalys

incremental_details_tanzania <- data.frame(inc_dalys = c(NA,tim_worry_tzeecc_inc_dalys,tim_worry_tzeeccaoc_inc_dalys),
                                          inc_costs = c(NA, tim_worry_tzeecc_inc_costs, tim_worry_tzeeccaoc_inc_costs),
                                          ICER = c(NA, tim_worry_tzeecc_ICER, tim_worry_tzeeccaos_ICER))


#create final dataset

final_halfnumbers <- data.frame(Comparator = c(rep("No Critical Care", 3), rep(rep("Tz Critical Care"),3)),
                                Intervention = c("No Intervention", "EECC", "ACC",
                                                 "No Intervention", "EECC", "ACC"))
binding_tim_results <- rbind(halfnumbers_mean_nothing,halfnumbers_mean_tanzania)
binding_inc_results<- rbind(incremental_details_nothing,incremental_details_tanzania)


final_halfnumbers1 <- cbind(final_halfnumbers, binding_tim_results, binding_inc_results)

