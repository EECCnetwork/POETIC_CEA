beta_mom <- function(mean, SE){
  term <- mean * (1 - mean)/SE - 1
  alpha <- mean * term
  beta <- (1 - mean) * term
  if (SE >= mean * (1 - mean)) stop("SE must be less than mean * (1 - mean)")
  return(list(alpha = alpha, beta = beta))
}

gamma_mom <- function(mean, sd){
  if (mean > 0){
    theta <- sd^2/mean
    kappa <- mean/theta
  } else{
    stop("Mean must be positive")
  }
  return(list(kappa = kappa, theta = theta))
}

