######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)
library(heemod)

#load the information


source("Markov_Model/probabilistic_analysis/probabilistic_nothing_vs_interventions.R")

source("Markov_Model/probabilistic_analysis/probabilistic_tanzania_vs_interventions.R")


source("Markov_Model/probabilistic_analysis/probabilistic_isaric_vs_interventions.R")

#no critical care scenario

nothing_deaths <- results_func(nothing_dat$DEATHS)
nothing_deaths_final <- data.frame(DeathMean = nothing_deaths$mean_yes,
                                   DeathMin = nothing_deaths$range_low,
                                   DeathMax = nothing_deaths$range_high,
                                   DeathMedian = nothing_deaths$median_yes)

no_eecc_deaths_results <- results_func(no_eecc_dat$DEATHS)
no_eecc_deaths_results_final <- data.frame(DeathMean = no_eecc_deaths_results$mean_yes,
                                            DeathMin = no_eecc_deaths_results$range_low,
                                            DeathMax = no_eecc_deaths_results$range_high,
                                            DeathMedian = no_eecc_deaths_results$median_yes)

no_eeccaos_deaths_results <- results_func(no_eeccaos_dat$DEATHS)
no_eeccaos_deaths_results_final <- data.frame(DeathMean = no_eeccaos_deaths_results$mean_yes,
                                               DeathMin = no_eeccaos_deaths_results$range_low,
                                               DeathMax = no_eeccaos_deaths_results$range_high,
                                               DeathMedian = no_eeccaos_deaths_results$median_yes)

#tz critical care scenario

tanzania_deaths <- results_func(tanzania_dat$DEATHS)
tanzania_deaths_final <- data.frame(DeathMean = tanzania_deaths$mean_yes,
                                   DeathMin = tanzania_deaths$range_low,
                                   DeathMax = tanzania_deaths$range_high,
                                   DeathMedian = tanzania_deaths$median_yes)

tz_eecc_deaths_results <- results_func(tz_eecc_dat$DEATHS)
tz_eecc_deaths_results_final <- data.frame(DeathMean = tz_eecc_deaths_results$mean_yes,
                                           DeathMin = tz_eecc_deaths_results$range_low,
                                           DeathMax = tz_eecc_deaths_results$range_high,
                                           DeathMedian = tz_eecc_deaths_results$median_yes)

tz_eeccaos_deaths_results <- results_func(tz_eeccaos_dat$DEATHS)
tz_eeccaos_deaths_results_final <- data.frame(DeathMean = tz_eeccaos_deaths_results$mean_yes,
                                              DeathMin = tz_eeccaos_deaths_results$range_low,
                                              DeathMax = tz_eeccaos_deaths_results$range_high,
                                              DeathMedian = tz_eeccaos_deaths_results$median_yes)

#is critical care scenario

isaric_deaths <- results_func(isaric_dat$DEATHS)
isaric_deaths_final <- data.frame(DeathMean = isaric_deaths$mean_yes,
                                    DeathMin = isaric_deaths$range_low,
                                    DeathMax = isaric_deaths$range_high,
                                    DeathMedian = isaric_deaths$median_yes)

is_eecc_deaths_results <- results_func(is_eecc_dat$DEATHS)
is_eecc_deaths_results_final <- data.frame(DeathMean = is_eecc_deaths_results$mean_yes,
                                           DeathMin = is_eecc_deaths_results$range_low,
                                           DeathMax = is_eecc_deaths_results$range_high,
                                           DeathMedian = is_eecc_deaths_results$median_yes)

is_eeccaos_deaths_results <- results_func(is_eeccaos_dat$DEATHS)
is_eeccaos_deaths_results_final <- data.frame(DeathMean = is_eeccaos_deaths_results$mean_yes,
                                              DeathMin = is_eeccaos_deaths_results$range_low,
                                              DeathMax = is_eeccaos_deaths_results$range_high,
                                              DeathMedian = is_eeccaos_deaths_results$median_yes)


comparator1 <- c(rep("No Critical Care", 3), rep("District Level Critical Care", 3), rep("Regional or Referral Critical Care", 3))
intervention1 <- c(rep(c("No Intervention", "Only EECC", "EECC & AOS"),3))

deaths1 <- rbind(nothing_deaths_final, no_eecc_deaths_results_final, no_eeccaos_deaths_results_final,
                tanzania_deaths_final,tz_eecc_deaths_results_final, tz_eeccaos_deaths_results_final,
                isaric_deaths_final,is_eecc_deaths_results_final, is_eeccaos_deaths_results_final)


deaths_tab <- cbind(comparator1, intervention1, deaths1/pop)






write.csv(deaths_tab, "Markov_Model/probabilistic_analysis/Results/base_case/deaths_table.csv")
