######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)

####load data

source("Markov_Model/probabilistic_analysis/probabilistic_isaric_vs_interventions.R")
##net health benefits approach

##ceac for no critical care vs only EECC

WTP_vec <- seq(0,2000,by = 50)
isaric_vs_eecc_prob <- rep(NA, times = length(WTP_vec))

for (wtp in 1:length(WTP_vec))
{
  DALY_vec1 <- isaric_DALY_dat - is_eecc_DALY_dat ###1000
  cost_vec1 <- (is_eecc_totalcost_dat - isaric_totalcost_dat)/WTP_vec[wtp] ###5000 col, 1000 row
  PSA_vec <- DALY_vec1- cost_vec1
  isaric_vs_eecc_prob[wtp] <- sum(PSA_vec >= 0)/length(DALY_vec1)
}

plot(WTP_vec, isaric_vs_eecc_prob)

##ceac for no critical care vs EECC + AOS

WTP_vec <- seq(0,2000,by = 50)
isaric_vs_eeccaos_prob <- rep(NA, times = length(WTP_vec))

for (wtp in 1:length(WTP_vec))
{
  DALY_vec1 <- isaric_DALY_dat - is_eeccaos_DALY_dat ###1000
  cost_vec1 <- (is_eeccaos_totalcost_dat - isaric_totalcost_dat)/WTP_vec[wtp] ###5000 col, 1000 row
  PSA_vec <- DALY_vec1- cost_vec1
  isaric_vs_eeccaos_prob[wtp] <- sum(PSA_vec >= 0)/length(DALY_vec1)
}

plot(WTP_vec, isaric_vs_eeccaos_prob)

##ceac for no critical care + EECC vs EECC + AOS

WTP_vec <- seq(0,2000,by = 50)
is_eecc_vs_eeccaos_prob <- rep(NA, times = length(WTP_vec))

for (wtp in 1:length(WTP_vec))
{
  DALY_vec1 <- is_eecc_DALY_dat - is_eeccaos_DALY_dat ###1000
  cost_vec1 <- (is_eeccaos_totalcost_dat - is_eecc_totalcost_dat)/WTP_vec[wtp] ###5000 col, 1000 row
  PSA_vec <- DALY_vec1- cost_vec1
  is_eecc_vs_eeccaos_prob[wtp] <- sum(PSA_vec >= 0)/length(DALY_vec1)
}

plot(WTP_vec, is_eecc_vs_eeccaos_prob)

###CEAC Graph

dat_ceac_all_is = data.frame(label = c(rep("EECC",length(WTP_vec)), rep("ACC", length(WTP_vec))),
                          val = c(isaric_vs_eecc_prob, isaric_vs_eeccaos_prob),
                          WTP = rep(WTP_vec,2))

ceac_isaric <- ggplot(data = dat_ceac_all_is, aes(x = WTP, y = val, col = label)) + 
  scale_colour_manual(values = c("EECC" = "#39568CFF", 
                                 "ACC" = "#73D055FF")) +
  geom_line(size = 1) +
  ggtitle("Comparator = Regional or Referral Critical Care")+
  #geom_rect(aes(xmin=19, xmax=101, ymin=0, ymax=Inf),col = "grey", alpha = 0.005) +
  geom_vline(xintercept=c(101), linetype="dotted") + 
  scale_y_continuous(limits = c(0, 1), breaks = c(seq(0, 1, by = 0.1))) +
  theme_bw() + 
  labs(colour = "Intervention") +
  ylab('Probability of being cost-effective (%)') +
  xlab("Willingness-to-pay (USD per DALY)") + 
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        legend.position = "none")


