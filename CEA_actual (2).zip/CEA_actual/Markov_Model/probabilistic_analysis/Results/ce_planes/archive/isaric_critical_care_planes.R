######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)


####load data

source("Markov_Model/probabilistic_analysis/probabilistic_isaric_vs_interventions.R")
##isaric vs eecc

is_critical_care_total_cost <- isaric_totalcost_dat
is_critical_care_total_DALYs <- isaric_DALY_dat

is_eecc_total_cost <- is_eecc_totalcost_dat
is_eecc_total_DALYs <- is_eecc_DALY_dat

is_eeccaos_total_cost <- is_eeccaos_totalcost_dat
is_eeccaos_total_DALYs <- is_eeccaos_DALY_dat

is_scenario1_incDALYs <- (is_critical_care_total_DALYs - is_eecc_total_DALYs)
is_scenario1_incCOSTs <- (is_eecc_total_cost - is_critical_care_total_cost)

is_scenario1_increments <- data.frame(inc_COSTS = is_scenario1_incCOSTs,
                                   inc_DALYs = is_scenario1_incDALYs,
                                   Intervention = "EECC")


is_scenario2_incDALYs <- (is_critical_care_total_DALYs - is_eeccaos_total_DALYs)
is_scenario2_incCOSTs <- (is_eeccaos_total_cost - is_critical_care_total_cost)

is_scenario2_increments <- data.frame(inc_COSTS = is_scenario2_incCOSTs,
                                   inc_DALYs = is_scenario2_incDALYs,
                                   Intervention = "ACC")

is_scenario3_incDALYs <- (is_eecc_total_DALYs - is_eeccaos_total_DALYs)
is_scenario3_incCOSTs <- (is_eeccaos_total_cost - is_eecc_total_cost)

#is_scenario3_increments <- data.frame(inc_COSTS = is_scenario3_incCOSTs,
                                   #inc_DALYs = is_scenario3_incDALYs,
                                   #Intervention = "EECC vs EECC & AOS")

is_all_scenario_dat <- rbind(is_scenario1_increments, is_scenario2_increments)


plane_is_critical_care <- ggplot(data = is_all_scenario_dat, aes(x = inc_DALYs, y = inc_COSTS, col = Intervention)) + 
  geom_point(size=0.5)+
  ggtitle("Comparator = Referral or Regional Critical Care") +
  scale_colour_manual(values = c("EECC" = "#39568CFF", 
                                 "ACC" = "#73D055FF")) +
  geom_hline(yintercept = 0, linetype="dashed") + 
  geom_vline(xintercept = 0, linetype="dashed") +
  theme_bw() + 
  labs(colour = "Scenario") +
  ylab('Incremental Costs') +
  xlab("Incremental DALYs") + 
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 45,vjust =0.5),
        legend.position = "none") 

