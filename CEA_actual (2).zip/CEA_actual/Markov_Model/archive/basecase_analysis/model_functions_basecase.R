######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)
library(heemod)


#markovmodel function

markov_function <- function(pop_n, time_horizon, triage_sev, triage_crit, 
                            crit2crit, crit2death,crit2discharge,crit2severe,
                            severe2crit, severe2death, severe2discharge, severe2severe){
  severe_pop_triage <- pop_n * triage_sev
  critical_pop_triage <- pop_n * triage_crit
  pop_severe <- c(severe_pop_triage, rep(0, time_horizon-1))
  pop_critical <- c(critical_pop_triage, rep(0, time_horizon-1))
  pop_death <- rep(0, time_horizon)
  pop_discharge <- rep(0, time_horizon)
  for(i in 2:time_horizon){
    pop_severe[i] <- (pop_severe[i - 1] + pop_critical[i - 1] * crit2severe) -  
                        (pop_severe[i - 1] * severe2crit) - 
                        (pop_severe[i - 1] * severe2death) - 
                        (pop_severe[i - 1] * severe2discharge)
    pop_critical[i] <- (pop_critical[i-1] + pop_severe[i - 1] * severe2crit) - 
                         (pop_critical[i-1] * crit2severe) - 
                          (pop_critical[i-1] * crit2death) -
                          (pop_critical[i-1] * crit2discharge)
    pop_death[i] <- (pop_severe[i - 1] * severe2death) + (pop_critical[i-1] * crit2death)
    pop_discharge[i] <- (pop_severe[i - 1] * severe2discharge) + (pop_critical[i-1] * crit2discharge)
  }
  popsev <- sum(pop_severe)
  popcrit <- sum(pop_critical)
  popdeath <- sum(pop_death)
  popdis <- sum(pop_discharge)
  states_go <- data.frame(Severe = popsev,
                          Critical = popcrit,
                          Death = popdeath,
                          Discharge = popdis)
  states_go}

#DALY calculation

DALY_calc <-function(outcome_dataset, age_mortprop1, age_mortprop2, age_mortprop3, age_entry1, age_entry2, age_entry3, life_expectancy){
  Deaths <- outcome_dataset[,3]
  LYL <- ((life_expectancy - age_entry1)*(age_mortprop1*Deaths))+((life_expectancy - age_entry2)*(age_mortprop2*Deaths))+
    ((life_expectancy - age_entry3)*(age_mortprop3*Deaths))
  Final <- cbind(Deaths, LYL)
}

#costing_calculation

costing_calc <- function(outcome_dataset, severe_cost, critical_cost, death_cost, discharge_cost){
  severecost <- outcome_dataset[,1] * severe_cost
  criticalcost <- outcome_dataset[,2] * critical_cost
  deathcost <- outcome_dataset[,3] * death_cost
  dischargecost <- outcome_dataset[,4] * discharge_cost
  totalcost <- severecost + criticalcost + deathcost + dischargecost
  costs <- data.frame(severecost, criticalcost, deathcost, dischargecost, totalcost)
}


