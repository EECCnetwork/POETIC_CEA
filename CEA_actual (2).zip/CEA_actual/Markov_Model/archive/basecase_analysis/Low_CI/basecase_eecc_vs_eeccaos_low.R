######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)



#EECC simulations

eecc_sims <- markov_function(pop_n = pop,
                           time_horizon = timehorizon,
                           triage_sev = triage_severe,
                           triage_crit = triage_critical,
                           crit2crit = eecc_critical_to_critical,
                           crit2death = eecc_critical_to_death,
                           crit2discharge = eecc_critical_to_discharge,
                           crit2severe = eecc_critical_to_severe,
                           severe2crit = eecc_severe_to_critical,
                           severe2death = eecc_severe_to_death,
                           severe2discharge = eecc_severe_to_discharge,
                           severe2severe = eecc_severe_to_severe)

eecc_LYLs <- DALY_calc(outcome_dataset = eecc_sims,
                          age_mortprop1 = age_strt_mort1_46to56,
                          age_mortprop2 = age_strt_mort2_57to67,
                          age_mortprop3 = age_strt_mort3_68to100,
                          age_entry1 = age_threshold1,
                          age_entry2 = age_threshold2,
                          age_entry3 = age_threshold3,
                          life_expectancy = ending_popn_age)

eecc_costs <- costing_calc(outcome_dataset = eecc_sims,
                               severe_cost = eecc_severe_costs,
                               critical_cost = eecc_critical_costs,
                               death_cost = eecc_death_costs,
                               discharge_cost = eecc_discharge_costs)


#EECC+AOS simulations

eeccaos_sims <- markov_function(pop_n = pop,
                               time_horizon = timehorizon,
                               triage_sev = triage_severe,
                               triage_crit = triage_critical,
                               crit2crit = eeccaos_critical_to_critical,
                               crit2death = eeccaos_critical_to_death,
                               crit2discharge = eeccaos_critical_to_discharge,
                               crit2severe = eeccaos_critical_to_severe,
                               severe2crit = eeccaos_severe_to_critical,
                               severe2death = eeccaos_severe_to_death,
                               severe2discharge = eeccaos_severe_to_discharge,
                               severe2severe = eeccaos_severe_to_severe)


eeccaos_LYLs <- DALY_calc(outcome_dataset = eeccaos_sims,
                          age_mortprop1 = age_strt_mort1_46to56,
                          age_mortprop2 = age_strt_mort2_57to67,
                          age_mortprop3 = age_strt_mort3_68to100,
                          age_entry1 = age_threshold1,
                          age_entry2 = age_threshold2,
                          age_entry3 = age_threshold3,
                          life_expectancy = ending_popn_age)


eeccaos_costs <- costing_calc(outcome_dataset = eeccaos_sims,
                              severe_cost = eeccaos_severe_costs,
                              critical_cost = eeccaos_critical_costs,
                              death_cost = eeccaos_death_costs,
                              discharge_cost = eeccaos_discharge_costs)
#ICER calculations

eecc_outcomes_mean <- data.frame(eecc_LYLs)
eecc_total_costs_mean <- data.frame(eecc_costs)
eeccaos_outcomes_mean <- data.frame(eeccaos_LYLs)
eeccaos_total_costs_mean <- data.frame(eeccaos_costs)

eecc_vs_eeccaos_icer_mean <- (eeccaos_total_costs_mean$totalcost - eecc_total_costs_mean$totalcost)/
  (eecc_outcomes_mean$LYL - eeccaos_outcomes_mean$LYL)

