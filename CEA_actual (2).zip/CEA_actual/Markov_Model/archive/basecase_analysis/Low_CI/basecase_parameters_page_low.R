######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)

#starting parameters

triage_severe <- 0.648
triage_critical <- 0.252
pop <- 1000
timehorizon <- 28

#Demographic parameters

starting_popn_age <- 46
ending_popn_age <- 70
age_strt_mort1_46to56 <- 0.313782991
age_strt_mort2_57to67 <- 0.404692082
age_strt_mort3_68to100 <- 0.281524927
age_threshold1 <- 46
age_threshold2 <- 57
age_threshold3 <- 68

#Clinical Effectiveness

eff_eecc_severe_to_critical <- 0.69
eff_eecc_severe_to_death <- 0.00
eff_eecc_severe_to_discharge <- 0.00
eff_eecc_critical_to_death <- 0.00
eff_eecc_critical_to_severe <- 0.00
eff_aos_critical_to_death <- 0.34
eff_aos_critical_to_severe <- 0.00


#No Critical Care transition parameters

nothing_critical_to_critical <- 0
nothing_critical_to_death <- 1
nothing_critical_to_discharge <- 0
nothing_critical_to_severe <- 0
nothing_severe_to_critical <- 1
nothing_severe_to_death <- 0
nothing_severe_to_discharge <- 0
nothing_severe_to_severe <- 0

#Africa transition parameters

africa_critical_to_critical <- 0.714285714
africa_critical_to_death <- 0.142857143
africa_critical_to_discharge <- 0.081632653
africa_critical_to_severe <- 0.06122449
africa_severe_to_critical <- 0.415309446
africa_severe_to_death <- 0.001628664
africa_severe_to_discharge <- 0.04267101
africa_severe_to_severe <- 0.540390879

#EECC transition parameters

eecc_critical_to_critical <- africa_critical_to_critical 
eecc_critical_to_death <- africa_critical_to_death * (1 - eff_eecc_critical_to_death)
eecc_critical_to_discharge <- africa_critical_to_discharge 
eecc_critical_to_severe <- africa_critical_to_severe * (1 + eff_eecc_critical_to_severe)
eecc_severe_to_critical <- africa_severe_to_critical * (1 - eff_eecc_severe_to_critical)
eecc_severe_to_death <- africa_severe_to_death * (1 - eff_eecc_severe_to_death)
eecc_severe_to_discharge <- africa_severe_to_discharge * (1 + eff_eecc_severe_to_discharge)
eecc_severe_to_severe <- africa_severe_to_severe

#AOS transition parameters

aos_critical_to_critical <- africa_critical_to_critical
aos_critical_to_death <- africa_critical_to_death * (1 - eff_aos_critical_to_death)
aos_critical_to_discharge <- africa_critical_to_discharge
aos_critical_to_severe <- africa_critical_to_severe * (1 + eff_aos_critical_to_severe)
aos_severe_to_critical <- africa_severe_to_critical 
aos_severe_to_death <- africa_severe_to_death 
aos_severe_to_discharge <- africa_severe_to_discharge 
aos_severe_to_severe <- africa_severe_to_severe
  
  
#EECC+AOS transition parameters

eeccaos_critical_to_critical <- africa_critical_to_critical
eeccaos_critical_to_death <- africa_critical_to_death * (1 - eff_aos_critical_to_death)
eeccaos_critical_to_discharge <- africa_critical_to_discharge
eeccaos_critical_to_severe <- africa_critical_to_severe * (1 + eff_aos_critical_to_severe)
eeccaos_severe_to_critical <- africa_severe_to_critical * (1 - eff_eecc_severe_to_critical)
eeccaos_severe_to_death <- africa_severe_to_death * (1 - eff_eecc_severe_to_death)
eeccaos_severe_to_discharge <- africa_severe_to_discharge * (1 + eff_eecc_severe_to_discharge)
eeccaos_severe_to_severe <- africa_severe_to_severe
  
  
#Nothing cost parameters
  
nothing_severe_costs <- 1
nothing_critical_costs <- 1
nothing_death_costs <- 1
nothing_discharge_costs <- 1

#Africa cost parameters

africa_severe_costs <- 10
africa_critical_costs <- 70
africa_death_costs <- 2
africa_discharge_costs <- 5

#EECC cost parameters

eecc_severe_costs <- 20
eecc_critical_costs <- 80
eecc_death_costs <- 2
eecc_discharge_costs <- 7

#AOS cost parameters

aos_severe_costs <- 0
aos_critical_costs <- 250
aos_death_costs <- 2
aos_discharge_costs <- 5

#EECC + AOS cost parameters

eeccaos_severe_costs <- 20
eeccaos_critical_costs <- 250
eeccaos_death_costs <- 2
eeccaos_discharge_costs <- 7
