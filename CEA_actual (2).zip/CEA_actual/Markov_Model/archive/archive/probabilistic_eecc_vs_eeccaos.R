######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)


#load data

source("Markov_Model/probabilistic_analysis/model_functions_probabilistic.R")

#source("Markov_Model/probabilistic_analysis/probabilistic_parameters_page.R")



#eecc simulations

eecc_sims <- as.data.frame(do.call(rbind, sapply(1:length(triage_critical), function(i){
  pop_n = pop
  time_horizon = timehorizon
  triage_sev = triage_severe[i]
  triage_crit = triage_critical[i]
  crit2crit = eecc_critical_to_critical[i]
  crit2death = eecc_critical_to_death[i]
  crit2discharge = eecc_critical_to_discharge[i]
  crit2severe = eecc_critical_to_severe[i]
  severe2crit = eecc_severe_to_critical[i]
  severe2death = eecc_severe_to_death[i]
  severe2discharge = eecc_severe_to_discharge[i]
  severe2severe = eecc_severe_to_severe[i]
  output <- markov_function(pop_n, time_horizon, triage_sev, triage_crit, 
                            crit2crit, crit2death,crit2discharge,crit2severe,
                            severe2crit, severe2death, severe2discharge, severe2severe)
  matrix(c(output), nrow = 1)}, simplify = FALSE)))


eecc_LYLs <- DALY_calc(DEATHS = unlist(eecc_sims[,3]),
                          age_mortprop1 = age_strt_mort1_18to45,
                          age_mortprop2 = age_strt_mort2_46to56,
                          age_mortprop3 = age_strt_mort3_57to67,
                          age_mortprop4 = age_strt_mort4_68to100,
                          age_entry1 = age_threshold1,
                          age_entry2 = age_threshold2,
                          age_entry3 = age_threshold3,
                          age_entry4 = age_threshold4,
                          life_expectancy = ending_popn_age)

eecc_costs <- costing_calc(outcome_dataset = eecc_sims,
                               severe_cost = eecc_severe_costs,
                               critical_cost = eecc_critical_costs,
                               death_cost = eecc_death_costs,
                               discharge_cost = eecc_discharge_costs)


#oNLY eeccaos
eeccaos_sims <- as.data.frame(do.call(rbind, sapply(1:length(triage_critical), function(i){
  pop_n = pop
  time_horizon = timehorizon
  triage_sev = triage_severe[i]
  triage_crit = triage_critical[i]
  crit2crit = eeccaos_critical_to_critical[i]
  crit2death = eeccaos_critical_to_death[i]
  crit2discharge = eeccaos_critical_to_discharge[i]
  crit2severe = eeccaos_critical_to_severe[i]
  severe2crit = eeccaos_severe_to_critical[i]
  severe2death = eeccaos_severe_to_death[i]
  severe2discharge = eeccaos_severe_to_discharge[i]
  severe2severe = eeccaos_severe_to_severe[i]
  output <- markov_function(pop_n, time_horizon, triage_sev, triage_crit, 
                            crit2crit, crit2death,crit2discharge,crit2severe,
                            severe2crit, severe2death, severe2discharge, severe2severe)
  matrix(c(output), nrow = 1)}, simplify = FALSE)))


eeccaos_LYLs <- DALY_calc(DEATHS = unlist(eeccaos_sims[,(3)]),
                          age_mortprop1 = age_strt_mort1_18to45,
                          age_mortprop2 = age_strt_mort2_46to56,
                          age_mortprop3 = age_strt_mort3_57to67,
                          age_mortprop4 = age_strt_mort4_68to100,
                          age_entry1 = age_threshold1,
                          age_entry2 = age_threshold2,
                          age_entry3 = age_threshold3,
                          age_entry4 = age_threshold4,
                          life_expectancy = ending_popn_age)


eeccaos_costs <- costing_calc(outcome_dataset = eeccaos_sims,
                              severe_cost = eeccaos_severe_costs,
                              critical_cost = eeccaos_critical_costs,
                              death_cost = eeccaos_death_costs,
                              discharge_cost = eeccaos_discharge_costs)

#probabilistic mean, ci low, ci high

eecc_dat <- data.frame(eecc_LYLs)
eecc_LYL_dat <- eecc_dat$LYL
eecc_outcome_results <- results_func(eecc_LYL_dat)

eecc_costdat <- data.frame(eecc_costs)
eecc_totalcost_dat <- eecc_costdat$totalcost
eecc_cost_results <- results_func(eecc_totalcost_dat)


eeccaos_dat <- data.frame(eeccaos_LYLs)
eeccaos_LYL_dat <- eeccaos_dat$LYL
eeccaos_outcome_results <- results_func(eeccaos_LYL_dat)

eeccaos_costdat <- data.frame(eeccaos_costs)
eeccaos_totalcost_dat <- eeccaos_costdat$totalcost
eeccaos_cost_results <- results_func(eeccaos_totalcost_dat)

eecc_vs_eeccaos_ICER <- (eeccaos_cost_results - eecc_cost_results)/
  (eecc_outcome_results - eeccaos_outcome_results)
