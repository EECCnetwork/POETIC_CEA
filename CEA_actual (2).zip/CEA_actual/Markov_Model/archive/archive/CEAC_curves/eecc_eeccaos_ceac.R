######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)

####load data

source("Markov_Model/probabilistic_analysis/model_functions_probabilistic.R")

source("Markov_Model/probabilistic_analysis/probabilistic_parameters_page.R")


source("Markov_Model/probabilistic_analysis/probabilistic_eecc_vs_eeccaos.R")

##net health benefits approach

##ceac

WTP_vec <- seq(0,2000,by = 50)
eecc_eeccaos_prob <- rep(NA, times = length(WTP_vec))

for (wtp in 1:length(WTP_vec))
{
  DALY_vec1 <- eecc_LYL_dat - eeccaos_LYL_dat ###1000
  cost_vec1 <- (eeccaos_totalcost_dat - eecc_totalcost_dat)/WTP_vec[wtp] ###5000 col, 1000 row
  PSA_vec <- DALY_vec1- cost_vec1
  eecc_eeccaos_prob[wtp] <- sum(PSA_vec >= 0)/length(DALY_vec1)
}

plot(WTP_vec, eecc_eeccaos_prob)
