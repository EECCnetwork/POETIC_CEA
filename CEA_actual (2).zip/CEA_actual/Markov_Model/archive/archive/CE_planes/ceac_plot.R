######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)

####load data

source("Markov_Model/probabilistic_analysis/CEAC_curves/africa_aos_ceac.R")
source("Markov_Model/probabilistic_analysis/CEAC_curves/africa_eecc_ceac.R")
source("Markov_Model/probabilistic_analysis/CEAC_curves/africa_eeccaos_ceac.R")
source("Markov_Model/probabilistic_analysis/CEAC_curves/eecc_eeccaos_ceac.R")
source("Markov_Model/probabilistic_analysis/CEAC_curves/nothing_eecc_ceac.R")


nothing_eecc_ceac = data.frame(values = nothing_eecc_prob,
                    WTP = WTP_vec,
                    Scenario = "Do Nothing vs EECC")

africa_eecc_ceac = data.frame(values = africa_eecc_prob,
                  WTP = WTP_vec,
                  Scenario = "Tanzania Baseline vs EECC")

africa_aos_ceac = data.frame(values = africa_aos_prob,
                   WTP = WTP_vec,
                   Scenario = "Tanzania Baseline vs AOS")

africa_eeccaos_ceac = data.frame(values = africa_eeccaos_prob,
                     WTP = WTP_vec,
                     Scenario = "Tanzania Baseline vs EECC + AOS")

eecc_eeccaos_ceac = data.frame(values = eecc_eeccaos_prob,
                    WTP = WTP_vec,
                    Scenario = "EECC vs EECC + AOS")


dat_ceac_all = rbind(nothing_eecc_ceac, africa_eecc_ceac, africa_aos_ceac, 
                     africa_eeccaos_ceac, eecc_eeccaos_ceac)

ggplot(data = dat_ceac_all, aes(x = WTP, y = values, col = Scenario)) + 
  scale_colour_manual(values = c("Do Nothing vs EECC" = "#000004", 
                                 "Tanzania Baseline vs EECC" = "#dd513a", 
                                 "Tanzania Baseline vs AOS" = "#8c2981", 
                                 "Tanzania Baseline vs EECC + AOS" = "#414487", 
                                 "EECC vs EECC + AOS" = "#22a884")) +
  geom_line(size = 1) +
  geom_vline(xintercept=560, size = 0.5, linetype="dotted") +
  scale_y_continuous(breaks = seq(0, 1.00, by = 0.1)) +
  theme_bw() + 
  scale_fill_hue(l=40, c=35)+
  labs(colour = "Scenario") +
  ylab('Probability of being cost-effective (%)') +
  xlab("Willingness-to-pay (USD per DALY)") + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())
