######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)

####load data

source("Markov_Model/probabilistic_analysis/model_functions_probabilistic.R")

source("Markov_Model/probabilistic_analysis/probabilistic_parameters_page.R")


source("Markov_Model/probabilistic_analysis/probabilistic_africa_vs_eeccaos.R")
##net health benefits approach

##ce plane

africa_eeccaos_alldat <- data.frame(comp_LYL = africa_LYL_dat,
                                comp_costs = africa_totalcost_dat,
                                int_LYL = eeccaos_LYL_dat,
                                int_costs = eeccaos_totalcost_dat)

africa_eeccaos_alldat$incrementaL_costs <- eeccaos_totalcost_dat - africa_totalcost_dat
africa_eeccaos_alldat$incremental_LYL <- africa_LYL_dat - eeccaos_LYL_dat

ce_africa_eeccaos <- ggplot(africa_eeccaos_alldat, aes(x=incremental_LYL, y=incrementaL_costs, col = "#414487")) +
  geom_point(size=2, shape=23) +
  geom_abline(intercept = 1, slope = 560, color="red", 
              linetype="dashed", size=1.5) +
  ggtitle("Tanzania Baseline vs EECC + AOS") +
  xlab('Incremental Life Years Lost (LYL)') +
  ylab("Incremental Costs ($)") + theme_bw() + 
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        legend.position = "none")

