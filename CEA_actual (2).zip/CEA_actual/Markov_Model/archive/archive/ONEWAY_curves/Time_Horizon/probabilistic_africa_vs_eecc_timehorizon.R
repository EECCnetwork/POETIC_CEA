######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)


#load data

source("Markov_Model/probabilistic_analysis/model_functions_probabilistic.R")

#source("Markov_Model/probabilistic_analysis/probabilistic_parameters_page.R")


#africa simulations

africa_sims <- as.data.frame(do.call(rbind, sapply(1:length(triage_critical), function(i){
  pop_n = pop
  time_horizon = timehorizon[i]
  triage_sev = triage_severe[i]
  triage_crit = triage_critical[i]
  crit2crit = africa_critical_to_critical[i]
  crit2death = africa_critical_to_death[i]
  crit2discharge = africa_critical_to_discharge[i]
  crit2severe = africa_critical_to_severe[i]
  severe2crit = africa_severe_to_critical[i]
  severe2death = africa_severe_to_death[i]
  severe2discharge = africa_severe_to_discharge[i]
  severe2severe = africa_severe_to_severe[i]
  output <- markov_function(pop_n, time_horizon, triage_sev, triage_crit, 
                            crit2crit, crit2death,crit2discharge,crit2severe,
                            severe2crit, severe2death, severe2discharge, severe2severe)
  matrix(c(output), nrow = 1)}, simplify = FALSE)))


africa_LYLs <- DALY_calc(DEATHS = unlist(africa_sims[,3]),
                          age_mortprop1 = age_strt_mort1_46to56,
                          age_mortprop2 = age_strt_mort2_57to67,
                          age_mortprop3 = age_strt_mort3_68to100,
                          age_entry1 = age_threshold1,
                          age_entry2 = age_threshold2,
                          age_entry3 = age_threshold3,
                          life_expectancy = ending_popn_age)

africa_costs <- costing_calc(outcome_dataset = africa_sims,
                               severe_cost = africa_severe_costs,
                               critical_cost = africa_critical_costs,
                               death_cost = africa_death_costs,
                               discharge_cost = africa_discharge_costs)


#africa simulations

eecc_sims <- as.data.frame(do.call(rbind, sapply(1:length(triage_critical), function(i){
  pop_n = pop
  time_horizon = timehorizon[i]
  triage_sev = triage_severe[i]
  triage_crit = triage_critical[i]
  crit2crit = eecc_critical_to_critical[i]
  crit2death = eecc_critical_to_death[i]
  crit2discharge = eecc_critical_to_discharge[i]
  crit2severe = eecc_critical_to_severe[i]
  severe2crit = eecc_severe_to_critical[i]
  severe2death = eecc_severe_to_death[i]
  severe2discharge = eecc_severe_to_discharge[i]
  severe2severe = eecc_severe_to_severe[i]
  output <- markov_function(pop_n, time_horizon, triage_sev, triage_crit, 
                            crit2crit, crit2death,crit2discharge,crit2severe,
                            severe2crit, severe2death, severe2discharge, severe2severe)
  matrix(c(output), nrow = 1)}, simplify = FALSE)))


eecc_LYLs <- DALY_calc(DEATHS = unlist(eecc_sims[,(3)]),
                          age_mortprop1 = age_strt_mort1_46to56,
                          age_mortprop2 = age_strt_mort2_57to67,
                          age_mortprop3 = age_strt_mort3_68to100,
                          age_entry1 = age_threshold1,
                          age_entry2 = age_threshold2,
                          age_entry3 = age_threshold3,
                          life_expectancy = ending_popn_age)


eecc_costs <- costing_calc(outcome_dataset = eecc_sims,
                              severe_cost = eecc_severe_costs,
                              critical_cost = eecc_critical_costs,
                              death_cost = eecc_death_costs,
                              discharge_cost = eecc_discharge_costs)

#probabilistic mean, ci low, ci high

africa_dat <- data.frame(africa_LYLs)
africa_LYL_dat <- africa_dat$LYL
africa_outcome_results <- results_func(africa_LYL_dat)

africa_costdat <- data.frame(africa_costs)
africa_totalcost_dat <- africa_costdat$totalcost
africa_cost_results <- results_func(africa_totalcost_dat)


eecc_dat <- data.frame(eecc_LYLs)
eecc_LYL_dat <- eecc_dat$LYL
eecc_outcome_results <- results_func(eecc_LYL_dat)

eecc_costdat <- data.frame(eecc_costs)
eecc_totalcost_dat <- eecc_costdat$totalcost
eecc_cost_results <- results_func(eecc_totalcost_dat)

africa_vs_eecc_ICER <- (eecc_cost_results - africa_cost_results)/
  (africa_outcome_results - eecc_outcome_results)
