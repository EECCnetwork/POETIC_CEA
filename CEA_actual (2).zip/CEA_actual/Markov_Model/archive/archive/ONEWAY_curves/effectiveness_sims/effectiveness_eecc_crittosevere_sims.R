######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)
library(EnvStats)

#load simulations

source("Markov_Model/probabilistic_analysis/model_functions_probabilistic.R")

source("Markov_Model/probabilistic_analysis/ONEWAY_curves/effectiveness_sims/effectiveness_eecc_crittosevere_parameter_page.R")

source("Markov_Model/probabilistic_analysis/probabilistic_africa_vs_aos.R")

source("Markov_Model/probabilistic_analysis/probabilistic_africa_vs_eecc.R")

source("Markov_Model/probabilistic_analysis/probabilistic_africa_vs_eeccaos.R")

source("Markov_Model/probabilistic_analysis/probabilistic_eecc_vs_eeccaos.R")

source("Markov_Model/probabilistic_analysis/probabilistic_nothing_vs_eecc.R")

#extract results

nothing_results <- one_way_sense(outcome_dat = nothing_LYLs, 
                                cost_dat = nothing_costs, 
                                parameter = eff_aos_critical_to_severe)
africa_results <- one_way_sense(outcome_dat = africa_LYLs, 
                               cost_dat = africa_costs, 
                               parameter = eff_aos_critical_to_severe)
eecc_results <- one_way_sense(outcome_dat = eecc_LYLs, 
                             cost_dat = eecc_costs, 
                             parameter = eff_aos_critical_to_severe)
aos_results <- one_way_sense(outcome_dat = aos_LYLs, 
                            cost_dat = aos_costs, 
                            parameter = eff_aos_critical_to_severe)
eeccaos_results <- one_way_sense(outcome_dat = eeccaos_LYLs, 
                                cost_dat = eeccaos_costs, 
                                parameter = eff_aos_critical_to_severe)


#scenario based net health benefits

nothing_eecc_NHB <- (nothing_results$LYL - eecc_results$LYL) - 
                    ((eecc_results$totalcost - nothing_results$totalcost)/560)

nothing_eecc_NHB_final <- data.frame(eff_aos_critical_to_severe = nothing_results$Group.1,
                                     NHB = nothing_eecc_NHB,
                                     label = nothing_results$label,
                                     scenario = "Do Nothing vs EECC")

africa_eecc_NHB <- (africa_results$LYL - eecc_results$LYL) - 
  ((eecc_results$totalcost - africa_results$totalcost)/560)

africa_eecc_NHB_final <- data.frame(eff_aos_critical_to_severe = africa_results$Group.1,
                                     NHB = africa_eecc_NHB,
                                    label = nothing_results$label,
                                    scenario = "Tanzania Baseline vs EECC")

africa_aos_NHB <- (africa_results$LYL - aos_results$LYL) - 
  ((aos_results$totalcost - africa_results$totalcost)/560)

africa_aos_NHB_final <- data.frame(eff_aos_critical_to_severe = africa_results$Group.1,
                                    NHB = africa_aos_NHB,
                                   label = nothing_results$label,
                                   scenario = "Tanzania Baseline vs AOS")

africa_eeccaos_NHB <- (africa_results$LYL - eeccaos_results$LYL) - 
  ((eeccaos_results$totalcost - africa_results$totalcost)/560)

africa_eeccaos_NHB_final <- data.frame(eff_aos_critical_to_severe = africa_results$Group.1,
                                   NHB = africa_eeccaos_NHB,
                                   label = nothing_results$label,
                                   scenario = "Tanzania Baseline vs EECC + AOS")

eecc_eeccaos_NHB <- (eecc_results$LYL - eeccaos_results$LYL) - 
  ((eeccaos_results$totalcost - eecc_results$totalcost)/560)

eecc_eeccaos_NHB_final <- data.frame(eff_aos_critical_to_severe = eecc_results$Group.1,
                                       NHB = eecc_eeccaos_NHB,
                                     label = nothing_results$label,
                                     scenario = "EECC vs EECC + AOS")

triage_one_waydat <- rbind(nothing_eecc_NHB_final, africa_eecc_NHB_final,
                            africa_aos_NHB_final, africa_eeccaos_NHB_final,
                           eecc_eeccaos_NHB_final)

mean_dat <- subset(triage_one_waydat, subset = label %in% c("Mean"))
cilow_dat  <- subset(triage_one_waydat, subset = label %in% c("CI_low"))
cihigh_dat  <- subset(triage_one_waydat, subset = label %in% c("CI_high"))

agg_dat <- data.frame(mean_dat, CI_high = cilow_dat$NHB, CI_low = cihigh_dat$NHB)

triage_plot <-ggplot(agg_dat, aes(x = eff_aos_critical_to_severe,y = NHB,ymin = CI_high,
                                                 ymax = CI_low, colour=scenario)) + 
  geom_line() +
  geom_point()+
  scale_x_continuous(limits = c(0, 1), breaks = c(seq(0, 1, by = 0.1))) +
  scale_y_continuous(limits = c(-5000, 12000), breaks = c(seq(-5000, 12000, by = 1000))) +
  scale_colour_manual(values = c("Do Nothing vs EECC" = "#000004", 
                                 "Tanzania Baseline vs EECC" = "#dd513a", 
                                 "Tanzania Baseline vs AOS" = "#8c2981", 
                                 "Tanzania Baseline vs EECC + AOS" = "#414487", 
                                 "EECC vs EECC + AOS" = "#22a884")) +
  geom_hline(yintercept=0, size = 0.5, linetype="dotted") +
  theme_bw() +
  ggtitle("Clinical Effectiveness Sensitivity Analysis") +
  ylab("Conditional Expected Net Health Benefits") +
  xlab("Reduction in critical to severe transition due to EECC effectiveness") +
  theme(legend.position = "right",
        axis.text.x=element_text(size = 15),
        axis.text.y=element_text(size = 15),
        axis.title.x = element_text(size = 15),
        axis.title.y = element_text(size = 15),
        panel.background = element_blank(),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        panel.border = element_rect(colour = "black", fill=NA, size=1),
        legend.text=element_text(size=13),
        legend.title=element_text(size=13)) + labs(colour = "Scenario")

