######ISARIC DATASET######
#Author - Hiral A Shah
#Date - 02/08/2021
##########################
library(RColorBrewer)
library(matrixStats)
library(data.table)
library(ggplot2)
library(reshape2)
library(data.table) 
library(dplyr)
library(usdm)
library(tidyverse)
library(MultinomialCI)
library(msm)
library(DescTools)
library(markovchain)
library(EnvStats)

#starting parameters

set.seed(123)

nyear <- 1000

eff_eecc_critical_to_death <- c(rep(0.00,nyear),rep(0.10,nyear),rep(0.20,nyear),rep(0.30,nyear),
                                 rep(0.40,nyear),rep(0.50,nyear),rep(0.60,nyear),rep(0.70,nyear),
                                 rep(0.80,nyear),rep(0.90,nyear),rep(1.00,nyear))

sens_n <- length(eff_eecc_critical_to_death)

triage_severe <- runif(n = sens_n, min = 0.648, max = 0.792)
triage_critical <- runif(n = sens_n, min = 0.252, max = 0.308)

pop <- 1000
timehorizon <- 28

#Demographic parameters

starting_popn_age <- 46
ending_popn_age <- 70
age_strt_mort1_46to56 <- 0.313782991
age_strt_mort2_57to67 <- 0.404692082
age_strt_mort3_68to100 <- 0.281524927
age_threshold1 <- 46
age_threshold2 <- 57
age_threshold3 <- 68



#Clinical Effectiveness - triangular distributions
eff_eecc_severe_to_death <- rtri(n = sens_n, min = 0.1, max = 0.9, mod = 0.69)
eff_eecc_severe_to_critical <- rtri(n = sens_n, min = 0.1, max = 0.9, mod = 0.69)
eff_eecc_severe_to_discharge <- rtri(n = sens_n, min = 0.1, max = 0.9, mod = 0.69)

eff_eecc_critical_to_severe <- rtri(n = sens_n, min = 0.1, max = 0.9, mod = 0.69)
eff_aos_critical_to_death <- rtri(n = sens_n, min = 0.1, max = 0.9, mod = 0.34)
eff_aos_critical_to_severe <- rtri(n = sens_n, min = 0.1, max = 0.9, mod = 0.69)


#No Critical Care transition parameters

nothing_critical_to_critical <- rep(0,sens_n)
nothing_critical_to_death <- rtri(n = sens_n, mod = 0.75, min = 0.5, max = 1)
nothing_critical_to_discharge <- rep(0,sens_n)
nothing_critical_to_severe <- rtri(n = sens_n, mod = 0.25, min = 0, max = 0.5)
nothing_severe_to_critical <- rtri(n = sens_n, mod = 0.75, min = 0.5, max = 1)
nothing_severe_to_death <- rep(0,sens_n)
nothing_severe_to_discharge <- rtri(n = sens_n, mod = 0.05, min = 0, max = 0.1)
nothing_severe_to_severe <- rtri(n = sens_n, mod = 0.2, min = 0.1, max = 0.3)

#Africa transition parameters

africa_critical_to_critical <-  rtri(n = sens_n, mod = 0.714285714, min = 0.612244898, max = 0.845236045043409)
africa_critical_to_death <-  rtri(n = sens_n, mod = 0.142857143, min = 0.040816327, max = 0.273807474)
africa_critical_to_discharge <-  rtri(n = sens_n, mod = 0.081632653, min = 0, max = 0.21258298381892)
africa_critical_to_severe <-  rtri(n = sens_n, mod = 0.06122449, min = 0, max = 0.192174821)
africa_severe_to_critical <-  rtri(n = sens_n, mod = 0.415309446, min = 0.396742671009772, max = 0.433958001522844)
africa_severe_to_death <-  rtri(n = sens_n, mod = 0.001628664, min = 0, max = 0.02027722)
africa_severe_to_discharge <-  rtri(n = sens_n, mod = 0.04267101, min = 0.024104235, max = 0.061319565)
africa_severe_to_severe <- rtri(n = sens_n, mod = 0.540390879, min = 0.521824104234528, max = 0.559039435)

#EECC transition parameters

eecc_critical_to_critical <- africa_critical_to_critical 
eecc_critical_to_death <- africa_critical_to_death * (1 - eff_eecc_critical_to_death)
eecc_critical_to_discharge <- africa_critical_to_discharge 
eecc_critical_to_severe <- africa_critical_to_severe * (1 + eff_eecc_critical_to_severe)
eecc_severe_to_critical <- africa_severe_to_critical * (1 - eff_eecc_severe_to_critical)
eecc_severe_to_death <- africa_severe_to_death * (1 - eff_eecc_severe_to_death)
eecc_severe_to_discharge <- africa_severe_to_discharge * (1 + eff_eecc_severe_to_discharge)
eecc_severe_to_severe <- africa_severe_to_severe

#AOS transition parameters

aos_critical_to_critical <- africa_critical_to_critical
aos_critical_to_death <- africa_critical_to_death * (1 - eff_aos_critical_to_death)
aos_critical_to_discharge <- africa_critical_to_discharge
aos_critical_to_severe <- africa_critical_to_severe * (1 + eff_aos_critical_to_severe)
aos_severe_to_critical <- africa_severe_to_critical 
aos_severe_to_death <- africa_severe_to_death 
aos_severe_to_discharge <- africa_severe_to_discharge 
aos_severe_to_severe <- africa_severe_to_severe


#EECC+AOS transition parameters

eeccaos_critical_to_critical <- africa_critical_to_critical
eeccaos_critical_to_death <- africa_critical_to_death * (1 - eff_aos_critical_to_death)
eeccaos_critical_to_discharge <- africa_critical_to_discharge
eeccaos_critical_to_severe <- africa_critical_to_severe * (1 + eff_aos_critical_to_severe)
eeccaos_severe_to_critical <- africa_severe_to_critical * (1 - eff_eecc_severe_to_critical)
eeccaos_severe_to_death <- africa_severe_to_death * (1 - eff_eecc_severe_to_death)
eeccaos_severe_to_discharge <- africa_severe_to_discharge * (1 + eff_eecc_severe_to_discharge)
eeccaos_severe_to_severe <- africa_severe_to_severe


#Nothing cost parameters

nothing_severe_costs <- rtri(n = sens_n, mod = 1, min = 0, max = 5)
nothing_critical_costs <- rtri(n = sens_n, mod = 1, min = 0, max = 5)
nothing_death_costs <- rep(0,sens_n)
nothing_discharge_costs <- rep(0,sens_n)

#Africa cost parameters

africa_severe_costs <- rtri(n = sens_n, mod = 10, min =1, max = 20)
africa_critical_costs <- rtri(n = sens_n, mod = 50, min = 40, max = 70)
africa_death_costs <- rep(0,sens_n)
africa_discharge_costs <- rep(0,sens_n)

#EECC cost parameters

eecc_severe_costs <- rtri(n = sens_n, mod = 20, min =5, max = 30)
eecc_critical_costs <- rtri(n = sens_n, mod = 80, min =50, max = 100)
eecc_death_costs <- rep(0,sens_n)
eecc_discharge_costs <- rep(0,sens_n)

#AOS cost parameters

aos_severe_costs <- rep(0,sens_n)
aos_critical_costs <- rtri(n = sens_n, mod = 250, min = 200, max = 300)
aos_death_costs <-  rep(0,sens_n)
aos_discharge_costs <-  rep(0,sens_n)

#EECC + AOS cost parameters

eeccaos_severe_costs <- rtri(n = sens_n, mod = 20, min =5, max = 30)
eeccaos_critical_costs <- rtri(n = sens_n, mod = 250, min = 200, max = 300)
eeccaos_death_costs <- rep(0,sens_n)
eeccaos_discharge_costs <- rep(0,sens_n)
