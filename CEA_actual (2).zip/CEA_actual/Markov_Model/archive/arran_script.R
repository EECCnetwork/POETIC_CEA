
library(ggplot2)
population_A <- c(7200, rep(0, 27))
population_B <- c(2800, rep(0, 27))
population_C <- rep(0, 28)
prob_A_to_B <- 0.1
prob_A_to_C <- 0.2
prob_B_to_C <- 0.3
prob_die <- 0.5
for(i in 2:28){
  population_A[i] <- population_A[i - 1] - population_A[i - 1] * prob_A_to_B - population_A[i - 1] * prob_A_to_C
  population_B[i] <- population_B[i - 1] + population_A[i - 1] * prob_A_to_B - population_B[i - 1] * prob_B_to_C
  population_C[i] <- population_C[i - 1] + population_A[i - 1] * prob_A_to_C + population_B[i - 1] * prob_B_to_C - population_C[i - 1] * prob_die
}

states_go <- data.frame(time = 1:28,
                         population = rep(paste0("Population ", c(c("A", "B", "C"))), each = 28),
                         value = c(population_A, population_B, population_C))

ggplot(data = states_go) +
  geom_line(aes(x = time, y = value, color = population)) +
  theme_minimal()

